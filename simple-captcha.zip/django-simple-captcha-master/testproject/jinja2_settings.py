from .settings import *  # noqa

FORM_RENDERER = 'django.forms.renderers.Jinja2'
